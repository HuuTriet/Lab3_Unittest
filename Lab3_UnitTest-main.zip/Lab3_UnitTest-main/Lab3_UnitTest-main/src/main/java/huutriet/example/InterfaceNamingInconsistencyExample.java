package huutriet.example;

interface Loginhandler {
    boolean login(String username, String password);
}
